package com.petadoption.pet_adoption_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
